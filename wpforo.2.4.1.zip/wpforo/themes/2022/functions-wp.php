<?php
// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * wpForo Classic Theme - WordPress theme specific functions
 * @hook: action - 'after_setup_theme'
 * @description: WordPress theme functions, for wpForo theme functions use functions.php file.
 * @theme: Classic
 */
